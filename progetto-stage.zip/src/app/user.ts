export interface User{
    userId: number;
    firstName: string;
    lastName: string;
    phoneNumber: number;
    emailAddress: string;
}
